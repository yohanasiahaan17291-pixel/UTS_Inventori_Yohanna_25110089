package dao;

import koneksi.Koneksi;
import model.Barang;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class BarangDAO {
    public boolean insert(Barang b){
        String sql = "INSERT INTO barang(kode_barang, nama_barang, kategori, stok) VALUES (?,?,?,?)";
        try(Connection c=Koneksi.getConnection(); PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1,b.getKodeBarang());
            ps.setString(2,b.getNamaBarang());
            ps.setString(3,b.getKategori());
            ps.setInt(4,b.getStok());
            return ps.executeUpdate()>0;
        }catch(Exception e){ e.printStackTrace(); return false; }
    }
    public boolean update(Barang b){
        String sql = "UPDATE barang SET nama_barang=?, kategori=?, stok=? WHERE kode_barang=?";
        try(Connection c=Koneksi.getConnection(); PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1,b.getNamaBarang());
            ps.setString(2,b.getKategori());
            ps.setInt(3,b.getStok());
            ps.setString(4,b.getKodeBarang());
            return ps.executeUpdate()>0;
        }catch(Exception e){ e.printStackTrace(); return false; }
    }
    public boolean delete(String kode){
        try(Connection c=Koneksi.getConnection(); PreparedStatement ps=c.prepareStatement("DELETE FROM barang WHERE kode_barang=?")){
            ps.setString(1,kode); return ps.executeUpdate()>0;
        }catch(Exception e){ return false; }
    }
    public DefaultTableModel getAll(){
        DefaultTableModel m=new DefaultTableModel();
        m.addColumn("Kode Barang"); m.addColumn("Nama Barang"); m.addColumn("Kategori"); m.addColumn("Stok");
        String sql="SELECT kode_barang, nama_barang, kategori, stok FROM barang";
        try(Connection c=Koneksi.getConnection(); Statement s=c.createStatement(); ResultSet rs=s.executeQuery(sql)){
            while(rs.next()){
                m.addRow(new Object[]{rs.getString("kode_barang"), rs.getString("nama_barang"), rs.getString("kategori"), rs.getInt("stok")});
            }
        }catch(Exception e){ e.printStackTrace(); }
        return m;
    }
}