package model;

public class Barang {
    private String kodeBarang;
    private String namaBarang;
    private String kategori;
    private int stok;
    public Barang(){}
    public Barang(String kode, String nama, String kategori, int stok){
        this.kodeBarang=kode; this.namaBarang=nama; this.kategori=kategori; this.stok=stok;
    }
    public String getKodeBarang(){return kodeBarang;} public void setKodeBarang(String k){kodeBarang=k;}
    public String getNamaBarang(){return namaBarang;} public void setNamaBarang(String n){namaBarang=n;}
    public String getKategori(){return kategori;} public void setKategori(String k){kategori=k;}
    public int getStok(){return stok;} public void setStok(int s){stok=s;}
}